#include "sll.h"

int sl_delete_element(Slist **head, data_t data)
{
    if (*head == NULL)
    {
        return FAILURE;
    }

    Slist *temp = *head;
    Slist *temp1;

    if ( temp->data == data )
    {
        *head = temp->link;
        free(temp);
        return SUCCESS;
    }

    while(temp)
    {
        if (temp->data != data)
        {
            temp1 = temp;
            temp = temp->link;
        }
        else
        {
            temp1->link = temp->link;
            free(temp);
            return SUCCESS;
            
        }
    }
    return DATA_NOT_FOUND;  

}