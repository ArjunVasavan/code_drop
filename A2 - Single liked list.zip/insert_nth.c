#include "sll.h"

int sl_insert_nth(Slist **head, data_t data, data_t n)
{
    if (*head == NULL && n != 1)
    {
        return LIST_EMPTY;
        
    }

    else
    {
        Slist *temp = *head;
        Slist *temp1;

        int i = 1;
        while(temp)
        {
            if( i==n )
            {
                break;
            }
            temp1 = temp;
            temp = temp->link;
            i++;
        }

        if (i != n)
        {
            return POSITION_NOT_FOUND;
        }

        if ( i == 1 )
        {
            Slist *new = malloc(sizeof(Slist));

            if (!new)
            {
                return FAILURE;
            }

            new->data = data;
            new->link = temp;
            *head = new;
            return SUCCESS;
        }

        Slist *new = malloc(sizeof(Slist));

        new->data = data;
        new->link = temp;
        temp1->link = new;
        return SUCCESS;
    }

}