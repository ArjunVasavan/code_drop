#include "sll.h"

int sl_insert_before(Slist **head, data_t g_data, data_t ndata)
{
    if (*head == NULL)
    {
        return LIST_EMPTY;
    }

    Slist *temp = *head;
    Slist *temp1;

    while(temp)
    {
        if (temp->data != g_data)
        {
            temp1 = temp;
            temp = temp->link;
        }
        else
        {
            if ( temp == *head )
            {
                Slist *new = malloc(sizeof(Slist));

                if (!new)
                {
                    return FAILURE;
                }

                new->data = ndata;
                new->link = temp;
                *head = new;
                return SUCCESS;
            }
            Slist *new = malloc(sizeof(Slist));

            if (!new)
            {
                return FAILURE;
            }

            new->data = ndata;
            new->link = temp;
            temp1->link = new;
            return SUCCESS;
        }
    }
    return DATA_NOT_FOUND;

}