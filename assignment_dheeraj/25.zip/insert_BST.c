#include "tree.h"

int insert_into_BST(Tree_t **root, int data)
{
    Tree_t *new = malloc(sizeof(Tree_t));
    if (new == NULL)
        return FAILURE;

    new->data = data;
    new->left = NULL;
    new->right = NULL;

    if (*root == NULL)
    {
        *root = new;
        return SUCCESS;
    }

    Tree_t *temp = *root;
    Tree_t *parent = NULL;

    while (temp != NULL)
    {
        parent = temp;

        if (data < temp->data)
            temp = temp->left;
        else if (data > temp->data)
            temp = temp->right;
        else
        {
            free(new);
            return FAILURE;
        }
    }

    if (data < parent->data)
        parent->left = new;
    else
        parent->right = new;

    return SUCCESS;
}