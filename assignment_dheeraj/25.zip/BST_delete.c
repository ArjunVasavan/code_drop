#include "tree.h"

extern int status;

Tree_t * delete_BST(Tree_t *root, int data)
{
    if (root == NULL)
    {
        status = 0;
        return NULL;
    }

    if (data < root->data)
    {
        root->left = delete_BST(root->left, data);
    }
    else if (data > root->data)
    {
        root->right = delete_BST(root->right, data);
    }
    else
    {
        status = 1;

        if (root->left == NULL && root->right == NULL)
        {
            free(root);
            return NULL;
        }
        else if (root->left == NULL)
        {
            Tree_t *temp = root->right;
            free(root);
            return temp;
        }
        else if (root->right == NULL)
        {
            Tree_t *temp = root->left;
            free(root);
            return temp;
        }
        else
        {
            Tree_t *succ = root->right;
            while (succ->left != NULL)
                succ = succ->left;

            root->data = succ->data;
            root->right = delete_BST(root->right, succ->data);
        }
    }

    return root;
}