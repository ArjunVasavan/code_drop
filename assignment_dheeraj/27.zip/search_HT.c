#include "hash.h"

int search_HT(hash_t *arr, int data, int size)
{
    int index = data % size;

    // If bucket is empty
    if(arr[index].value == -1)
    {
        return DATA_NOT_FOUND;
    }

    // Check head node
    if(arr[index].value == data)
    {
        return SUCCESS;
    }

    // Traverse linked list
    hash_t *temp = arr[index].link;

    while(temp)
    {
        if(temp->value == data)
        {
            return SUCCESS;
        }
        temp = temp->link;
    }

    return DATA_NOT_FOUND;
}
