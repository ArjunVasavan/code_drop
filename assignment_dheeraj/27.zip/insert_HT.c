#include "hash.h"

int insert_HT(hash_t *arr, int element, int size)
{
    int index = element % size;

    // If bucket is empty
    if(arr[index].value == -1)
    {
        arr[index].value = element;
        return SUCCESS;
    }

    // Check if element already exists at head
    if(arr[index].value == element)
    {
        return FAILURE;
    }

    // Traverse linked list to check duplicate
    hash_t *temp = arr[index].link;
    while(temp)
    {
        if(temp->value == element)
        {
            return FAILURE;  // Duplicate element
        }
        temp = temp->link;
    }

    // Create new node for collision
    hash_t *new = malloc(sizeof(hash_t));
    if(new == NULL)
    {
        return FAILURE;
    }

    new->value = element;
    new->index = index;
    new->link = NULL;

    // Insert at end of linked list
    temp = &arr[index];
    while(temp->link)
    {
        temp = temp->link;
    }

    temp->link = new;

    return SUCCESS;
}
