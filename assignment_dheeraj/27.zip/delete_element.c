#include "hash.h"

int delete_element(hash_t *arr, int data, int size)
{
    int index = data % size;

    // If bucket empty
    if(arr[index].value == -1)
    {
        return DATA_NOT_FOUND;
    }

    hash_t *temp = &arr[index];
    hash_t *prev = NULL;

    // Case 1: Element at head and no chain
    if(temp->value == data && temp->link == NULL)
    {
        temp->value = -1;
        return SUCCESS;
    }

    // Case 2: Element at head and chain exists
    if(temp->value == data && temp->link != NULL)
    {
        hash_t *delete_node = temp->link;

        temp->value = delete_node->value;
        temp->link = delete_node->link;

        free(delete_node);
        return SUCCESS;
    }

    // Case 3: Element in linked list
    prev = temp;
    temp = temp->link;

    while(temp)
    {
        if(temp->value == data)
        {
            prev->link = temp->link;
            free(temp);
            return SUCCESS;
        }

        prev = temp;
        temp = temp->link;
    }

    return DATA_NOT_FOUND;
}
