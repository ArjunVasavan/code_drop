#include "hash.h"

void create_HT(hash_t *arr, int size)
{
    for(int i = 0; i < size; i++)
    {
        arr[i].index = i;     // store index
        arr[i].value = -1;    // -1 means empty
        arr[i].link = NULL;   // no linked nodes initially
    }
}
