#include "hash.h"

int destroy_HT(hash_t *arr, int size)
{
    for(int i = 0; i < size; i++)
    {
        hash_t *temp = arr[i].link;
        hash_t *next;

        // Free all linked list nodes
        while(temp)
        {
            next = temp->link;
            free(temp);
            temp = next;
        }

        // Reset bucket
        arr[i].value = -1;
        arr[i].link = NULL;
    }

    return SUCCESS;
}
