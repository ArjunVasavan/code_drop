#include "tree.h"

int main()
{
    Tree_t *root = NULL;
    int result;
    int option, data;

    while (1)
    {
        scanf("%d", &option);

        switch(option)
        {
            case 1:
                printf("Enter the data to insert into the BST : ");
                scanf("%d", &data);

                result = insert_into_BST(&root, data);

                if (result == DUPLICATE)
                    printf("INFO : Duplicate found\n");
                else if (result == FAILURE)
                    printf("INFO : Node not created\n");
                break;

            case 2:
                inorder(root);
                printf("\n");
                break;

            case 3:
                preorder(root);
                printf("\n");
                break;

            case 4:
                postorder(root);
                printf("\n");
                break;

            case 5:
                printf("Enter the element to be searched: ");
                scanf("%d", &data);

                if (root == NULL)
                {
                    printf("INFO : Tree is empty\n");
                }
                else
                {
                    result = search_BST(root, data);

                    if (result == SUCCESS)
                        printf("INFO : Data found\n");
                    else
                        printf("INFO : Data not found\n");
                }
                break;

            case 6:
                result = findmin(root);

                if (result == FAILURE)
                    printf("INFO : Tree is empty\n");
                else
                    printf("INFO : Minimum value in the tree is %d\n", result);
                break;

            case 7:
                result = findmax(root);

                if (result == FAILURE)
                    printf("INFO : Tree is empty\n");
                else
                    printf("INFO : Maximum value in the tree is %d\n", result);
                break;

            case 8:
                return SUCCESS;

            default:
                printf("Invalid Option\n");
        }
    }

    return 0;
}