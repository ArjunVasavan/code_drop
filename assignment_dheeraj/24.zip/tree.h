#ifndef TREE_H
#define TREE_H

#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define DUPLICATE -2
#define NOELEMENT -3
#define DATA_NOT_FOUND -4

typedef struct node
{
    int data;
    struct node *left;
    struct node *right;
} Tree_t;
int insert_into_BST(Tree_t **root, int data);
int search_BST(Tree_t *root, int data);
int findmin(Tree_t *root);
int findmax(Tree_t *root);
int inorder(Tree_t *root);
int preorder(Tree_t *root);
int postorder(Tree_t *root);
#endif