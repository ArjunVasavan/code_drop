#include "tree.h"
int search_BST(Tree_t *root, int data)
{
    while (root)
    {
        if (data == root->data)
            return SUCCESS;

        else if (data < root->data)
            root = root->left;
        else
            root = root->right;
    }

    return NOELEMENT;   // IMPORTANT
}