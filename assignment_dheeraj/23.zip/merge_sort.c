#include "main.h"

int merge_sort(int *array, int narray) {
    if (narray < 2) return 0;  // Base case: 0 or 1 element
    int mid = narray / 2;
    
    int *left = array;
    int nleft = mid;
    int *right = array + mid;
    int nright = narray - mid;
    
    merge_sort(left, nleft);
    merge_sort(right, nright);
    merge(array, narray, left, nleft, right, nright);
    return 0;
}
