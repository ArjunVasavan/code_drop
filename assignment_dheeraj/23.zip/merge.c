#include "main.h"

void merge(int *array, int narray, int *left, int nleft, int *right, int nright) {
    int *temp = (int *)malloc(narray * sizeof(int));
    if (!temp) return;  // Handle allocation failure silently
    
    int i = 0, j = 0, k = 0;
    
    // Merge while both subarrays have elements
    while (i < nleft && j < nright) {
        if (left[i] <= right[j]) {
            temp[k++] = left[i++];
        } else {
            temp[k++] = right[j++];
        }
    }
    
    // Copy remaining left elements
    while (i < nleft) {
        temp[k++] = left[i++];
    }
    
    // Copy remaining right elements
    while (j < nright) {
        temp[k++] = right[j++];
    }
    
    // Copy back to original array
    for (int idx = 0; idx < narray; idx++) {
        array[idx] = temp[idx];
    }
    
    free(temp);
}
