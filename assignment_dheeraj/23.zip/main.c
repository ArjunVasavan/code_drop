#include "main.h"
#include <stdio.h>
#include <stdlib.h>  // Add for malloc/free

int main() {
    int i, limit;

    printf("Enter the size of an array: ");  // Fixed \n to :
    scanf("%d", &limit);

    /* Dynamic array - safer than VLA */
    int *arr = (int *)malloc(limit * sizeof(int));
    if (arr == NULL) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    printf("Enter the array elements: ");
    for (i = 0; i < limit; i++) {
        scanf("%d", &arr[i]);
    }

    merge_sort(arr, limit);

    printf("Sorted array is: ");
    for (i = 0; i < limit; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");  // Add newline for clean output

    free(arr);  // Free memory
    return 0;
}
