#include "sll.h"

int sl_sort(Slist **head)
{
    if(*head == NULL)
    {
        return LIST_EMPTY;
    }
    int swapped;
    Slist *ptr1;
    Slist *lptr = NULL;
    do
    {
        /* code */
        swapped = 0;
        ptr1 = *head;

        while(ptr1->link != lptr)
        {
            if(ptr1->data > ptr1->link->data)
            {
                int temp = ptr1->data;
                ptr1->data = ptr1->link->data;
                ptr1->link->data = temp;

                swapped = 1;
            }
            ptr1 = ptr1->link;
        }
        lptr = ptr1;
    } while (swapped);
    return SUCCESS;
    

}